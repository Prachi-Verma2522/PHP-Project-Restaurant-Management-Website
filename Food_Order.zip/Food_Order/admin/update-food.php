<?php include('partials/menu.php'); ?>
<?php
            //check whether id is set or not
              if(isset($_GET['id'])) 
              {
                  $id = $_GET['id'];
                  $sql2 = "SELECT * FROM table_food WHERE id=$id";
                  $res2 = mysqli_query($conn, $sql2);
                  $row = mysqli_fetch_assoc($res2); // getting the value based on query executed

                  //get individual values of selected food
                  $title=$row['title'];
                  $description=$row['description'];
                  $price=$row['price'];
                  $current_category=$row['category_id'];
                  $featured=$row['featured'];
                  $active=$row['active'];
              }
              else
              {
                  header('location:'.SITEURL.'admin/manage-food.php');

              }
 ?>
<div class="main">
       <div class="wrapper">
           <h1>Update Food</h1>
           <br><br>
           <form action=""  method="POST" enctype="multi/part/form-data">
           <table class="tbl-30">
           <tr>
                   <td>Title:</td>
                   <td><input type="text" name="title" value="<?php echo $title; ?>"></td>
            </tr>
            <tr>
                   <td>Description:</td>
                   <td><textarea name="description" cols="30" rows="6"><?php echo $description; ?></textarea></td>
            </tr>
            <tr>
                <td>Price: </td>
                <td><input type="number" name="price" value="<?php echo $price; ?>"></td>
            </tr>
            <tr>
                <td>Upload a new Image: </td>
                <td><input type="file" name="image"></td>
            </tr>
            <tr>
                <td>Category: </td>
                <td>
                    <select name="category">
                        <?php
                           //Create php code to display categories from db
                           //1. Create sql to get all active categories from db
                           $sql="SELECT * FROM table_category WHERE active='Yes'" ;
                           // Execute query
                           $res=mysqli_query($conn, $sql);
                           //Count rows to check whether we have categories or not
                           $count=mysqli_num_rows($res);
                           if($count>0) 
                           {
                               while($row=mysqli_fetch_assoc($res)) {
                                   //getting details of category
                                   $category_title=$row['title'];
                                   $category_id=$row['id'];
                            
                                 //echo "<option value='$category_id'>$category_title</option>";
                                 ?>
<option  <?php if($current_category==$category_id){echo "Selected";} ?> value="<?php echo $category_id; ?>"><?php echo $category_title; ?></option>
                                 <?php
                               }
                           }
                           else
                           {
                            echo "<option value='0'>Category Not Found</option>";
                           }
                         ?>
                    </select>
                </td>
            </tr>

            </tr>
            <tr>
                <td>Featured:</td>
                <td>
                    <input <?php if($featured=="Yes") {echo "checked";} ?> type="radio" name="featured" value="Yes">Yes
                    <input <?php if($featured=="No") {echo "checked";} ?> type="radio" name="featured" value="No">No
                </td>
            </tr>
            <tr>
                <td>Active:</td>
                <td>
                    <input <?php if($active=="Yes") {echo "checked";} ?>type="radio" name="active" value="Yes">Yes
                    <input <?php if($active=="No") {echo "checked";} ?> type="radio" name="active" value="No">No
                </td>
            </tr>
            <tr>
                <td>
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <input type="submit" name="submit" value="Update Food" class="btn-secondary">
                </td>
            </tr> 
           </table>
           </form>

           <?php
           if(isset($_POST['submit']))
           {
               $id=$_POST['id'];
               $title=$_POST['title'];
               $description=$_POST['description'];
               $price=$_POST['price'];
               $category=$_POST['category'];
               $featured=$_POST['featured'];
               $active=$_POST['active'];

           //update food in db
           $sql3="UPDATE table_food SET
            title='$title',
            description='$description',
            price='$price',
            category_id='$category',
            featured = '$featured',
            active = '$active'
            WHERE id=$id
            ";
            // execute query
            $res3=mysqli_query($conn, $sql3);
            if($res3==true)
            {
                //Query executed and food updated
                $_SESSION['update'] = "<div class = 'success'>Food Updated Successfully</div>";
                header('location:'.SITEURL.'admin/manage-food.php');
            }
            else
            {
                //failed to update food
                $_SESSION['update'] = "<div class = 'error'>Failed to Update the Food</div>";
                header('location:'.SITEURL.'admin/manage-food.php');
            }
        }
        
           ?>
        </div>
    </div>
<?php include('partials/footer.php'); ?>