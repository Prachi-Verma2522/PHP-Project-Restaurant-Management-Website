<style>
    *{
  margin: 0;
  padding: 0;
}
.bgimg{
  width: 100%;
  height: 100vh;
  background-image: linear-gradient(27deg, darkred 50%, black 50%)
}
.centerdiv{
  width: 500px;
  height: 500px;
  position: absolute;
  top: 50%;
  left: 50%;
  background-color: red;
  transform: translate(-50%, -50%);
  background-image: linear-gradient(27deg, black 50%, darkred 50%)
}
/*#profilepic{
  width: 120px;
  height: 120px;
  border-radius: 50%;
  position: relative;
  top: -60px;
  left: calc( (350px - 120px) / 2 );
} */
h1{
  text-align: center;
  color: black;
  text-transform: uppercase;
  font-size: 2em;
  word-spacing: 10px;
  margin-top: -50px;
  margin-bottom: 50px;
  text-shadow: -2px 2px 1px red;
}
.box input[type = "text"],.box input[type = "password"]{
  border:0;
  background: none;
  display: block;
  margin: 20px auto;
  text-align: center;
  border: 2px solid transparent;
  padding: 14px 10px;
  width: 200px;
  outline: none;
  color: red;
  border-radius: 24px;
  transition: 0.25s;
}
.box input[type = "text"]:focus,.box input[type = "password"]:focus{
  width: 280px;
  border-color: red;
}
::placeholder{
 letter-spacing: 2px;
 color: red;
}
.btn-primary{
  border:0;
  background: none;
  display: block;
  margin: 20px auto;
  text-align: center;
  border: 2px solid red;
  padding: 14px 40px;
  outline: none;
  color: white;
  border-radius: 24px;
  transition: 0.25s;
  cursor: pointer;
}
.message{
  width: calc( 100% - 40px );
  line-height: 30px;
  display: block;
  margin: auto;
  color: red;
  background-color: black;
  text-transform: uppercase;
  font-size: 17px;
  text-align: center;
  padding-right: 20px;
  box-sizing: border-box;
  cursor: pointer;
  text-decoration: none;
}
.message a{
  color: white;
  font-size: 0.8em;
}
.mail{ 
width: calc( 100% - 40px );
  line-height: 30px;
  display: block;
  margin: auto;
  color: red;
  background-color: darkred;
  text-transform: uppercase;
  font-size: 17px;
  text-align: center;
  cursor: pointer;
  text-decoration: none;
}
div{
  color: white;
}
</style>
<?php include('../config/constants.php'); ?>

<html>
    <head>
        <title>Login- Restaurant Management System</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>

    <body>
        <div class="bgimg">
        <div clas="centerdiv">
            <center>
            <h1>Login</h1>
            <br> <br>

            <?php 
               if(isset($_SESSION['login'])) {
                   echo $_SESSION['login'];
                   unset($_SESSION['login']);
               }
               if(isset($_SESSION['no-login-message'])) {
                   echo $_SESSION['no-login-message'];
                   unset( $_SESSION['no-login-message']);
               }
            ?>
            <br><br>
            <form class="box" action="" method="POST">
                Username: <br>
                <input type="text" name="username" placeholder="Type your username"> <br> <br>
                Password:  <br>
                <input type="password" name="password" placeholder="Type your password">  <br> <br>
                <input type="submit" name="submit" value="Login" class="btn-primary">
                <br> <br>
            </form>
                
            <p>Created By: Prachi Verma</p>
            </center>
        </div>
            </div>
    </body>
</html>

<?php
   //Check whether Submit button is clicked or not 
   if(isset($_POST['submit']))
    {
        // Process the login
        // 1. Get the data from login form
        $username = $_POST['username'];
        $password = md5($_POST['password']);
        // 2. SQL to check whether credentials are correct or not
        $sql = "SELECT * FROM table_admin WHERE username ='$username' AND password='$password'" ;
        // 3. Execute query
        $res = mysqli_query($conn, $sql);
        // 4. Count rows to check whether user exists or not
        $count = mysqli_num_rows($res);
        if($count==1) {
            // User is exists
            $_SESSION['login'] = "<div class='success'> Login Successfully</div>" ;
            // Checking whether the user is logged in or out and if logout, will unset it 
            $_SESSION['user'] = $username;
            //redirecting to homepage
            header('location:'.SITEURL.'admin/');
        } 
        else{
              // User doesn't exists
              $_SESSION['login'] = "<div class='error'> Username or password did not match.</div>" ;
             //redirecting to homepage
             header('location:'.SITEURL.'admin/login.php');
            
            
                

        }



    }
?>