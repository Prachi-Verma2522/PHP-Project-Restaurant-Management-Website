<?php include('partials-front/menu.php'); ?>
  <?php
  //check whether food ID is set or not
  if(isset($_GET['food_id']))
  {
      //get food ID and deatils of the selected food
       $food_id=$_GET['food_id'];
       //get details of the selected food
       $sql= "SELECT * FROM table_food WHERE id=$food_id";
       //execute query
       $res=mysqli_query($conn, $sql);
       //count rows
       $count=mysqli_num_rows($res);
       //check whether data is availabel or not
       if($count==1)
       {
           //data is present
           // get data from db
           $row=mysqli_fetch_assoc($res);
           $title=$row['title'];
           $price=$row['price'];
           $image_name=$row['image_name'];
       }
       else
       {
           header('location:'.SITEURL);
       }
  }
  else
  {
      //redirect to homepage
      header('location:'.SITEURL);
  }
   ?>

    <!-- fOOD sEARCH Section Starts Here -->
    <section class="food-search">
        <div class="container">
            
            <h2 class="text-center text-white">Fill this form to confirm your order.</h2>

            <form action="" method="POST" class="order">
                <fieldset>
                    <legend>Selected Food</legend>

                    <div class="food-menu-img">
                        <?php
                        // check image is present or not
                        if($image_name=="") 
                        {
                            echo "<div class='error'>Image not availabel</div>";
                        }
                        else
                        {
                            ?>
              <img src="<?php echo SITEURL; ?>images/food/<?php echo $image_name; ?>" alt="Chicke Hawain Pizza" class="img-responsive img-curve">
                        <?php
                            
                        }

                        ?>

                    </div>
    
                    <div class="food-menu-desc">
                        <h3><?php echo $title; ?> </h3>
                        <input type="hidden" name="food" value="<?php echo $title; ?>">
                        <p class="food-price">Rs.<?php echo $price; ?></p>
                        <input type="hidden" name="price" value="<?php echo $price; ?>">

                        <div class="order-label">Quantity</div>
                        <input type="number" name="quantity" class="input-responsive" value="1" required>
                        
                    </div>

                </fieldset>
                
                <fieldset>
                    <legend>Delivery Details</legend>
                    <div class="order-label">Full Name</div>
                    <input type="text" name="full-name" placeholder="E.g. Adward Young" class="input-responsive" required>

                    <div class="order-label">Phone Number</div>
                    <input type="tel" name="contact" placeholder="E.g. 9843xxxxxx" class="input-responsive" required>

                    <div class="order-label">Email</div>
                    <input type="email" name="email" placeholder="E.g. hi@adward.com" class="input-responsive" required>

                    <div class="order-label">Address</div>
                    <textarea name="address" rows="10" placeholder="E.g. Street, City, Country" class="input-responsive" required></textarea>

                    <input type="submit" name="submit" value="Confirm Order" class="btn btn-primary">
                </fieldset>
            </form>
            <?php
            //check submit button is clicked or not
            if(isset($_POST['submit']))
            {
                //get all details from the form
                $food=$_POST['food'];
                $price=$_POST['price'];
                $quantity=$_POST['quantity'];
                $total=$price * $quantity;
                $order_date=date("Y-m-d h:i:sa"); // a is am or pm; order date
                $status= "Ordered";
                $customer_name=$_POST['full-name'];
                $customer_contact = $_POST['contact'];
                $customer_email=$_POST['email'];
                $customer_address=$_POST['address'];

                //saving the order data in db
                $sql2="INSERT INTO table_order SET
                food='$food',
                price='$price',
                quantity='$quantity',
                total='$total',
                order_date='$order_date',
                status='$status',
                customer_name='$customer_name',
                customer_contact='$customer_contact',
                customer_email='$customer_email',
                customer_address='$customer_address'
                ";

                //execute query
                $res2=mysqli_query($conn, $sql2);
                if($res2==true)
                {
                    $_SESSION['order'] = "<div class='success text-center'>Food Ordered Successfully</div>";
                    header('location:'.SITEURL);
                }
                else
                {
                    $_SESSION['order'] = "<div class='error text-center'>Failed to order pleases try again :(</div>";
                    header('location:'.SITEURL);
                }
            }
            ?>

        </div>
    </section>
    <!-- fOOD sEARCH Section Ends Here -->

    <?php include('partials-front/footer.php'); ?>