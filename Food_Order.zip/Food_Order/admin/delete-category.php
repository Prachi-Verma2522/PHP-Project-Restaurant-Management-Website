<?php
     include('../config/constants.php');
      //Check whether id is set or not
      if(isset($_GET['id']) AND isset($_GET['image_name']))
      {
          //Get the id and image
          $id = $_GET['id'];
          $image_name = $_GET['image_name'];

          //remove image from file
          if($image_name != "")
          {
              $path="../images/category/".$image_name;
              $remove = unlink($path);

              //failed to remove image then add an err msg
              if($remove==false)
              {
                  $_SESSION['remove'] = "<div class='error' >Failed to remove category image!</div>";
                  //redirect to manage category
                  header('location:'.SITEURL.'admin/manage-category.php');
                  die(); //stop process
              }
          }
          //delete it from db
          $sql = "DELETE FROM table_category WHERE id=$id";
          //execute query
          $res = mysqli_query($conn, $sql);
          if($res==true) 
          {
              $_SESSION['delete'] = "<div class='success'>Food Category Deleted Successfully</div>";
              header('location:'.SITEURL.'admin/manage-category.php');
          }
      }
      else
      {
        $_SESSION['delete'] = "<div class='error'> Failed to Delete this Food Category</div>";
          header('location:'.SITEURL.'admin/manage-category.php');

      }
?>
