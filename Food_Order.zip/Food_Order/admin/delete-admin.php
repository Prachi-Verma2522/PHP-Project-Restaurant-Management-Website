

<?php 

      include('../config/constants.php');
      // 1. Get id of admin to be deleted
      $id = $_GET['id'];
      // 2. Create sql query to delete admin
      $sql = "DELETE FROM table_admin WHERE id = $id";
      // 3. Execute the query
      $res = mysqli_query($conn, $sql);
      // 4. Check whether the query executed or not
      if($res == true) {
          $_SESSION['delete'] = "<div class='success'>Admin Deleted Successfully</div>";
          header('location:'.SITEURL.'admin/manage-admin.php');
      }
      else{
          $_SESSION['delete'] = "<div class='error'>Failed to Delete Admin, try again later</div>";
          header('location:'.SITEURL.'admin/manage-admin.php');

      }
?>
