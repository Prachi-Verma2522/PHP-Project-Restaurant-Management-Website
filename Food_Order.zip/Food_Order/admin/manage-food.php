<style>
table {
  border-collapse: collapse;
  width: 100%;
}
th, td {
  text-align: left;
  padding: 8px;
}
tr:nth-child(even) {
  background-color: #D6EEEE;
}
.btn-primary{
    background-color: #16a085;
    padding: 1%;
    color: white;
    text-decoration: none;
    font-weight: bold;
}
.btn-primary:hover{
    background-color: #27ae60;
}
.btn-secondary{
    background-color: black;
    padding: 1%;
    color: white;
    text-decoration: none;
    font-weight: bold;    
}
.btn-secondary:hover{
    background-color: #c0392b;
}
.btn-danger{
    background-color: #8e44ad;
    padding: 1%;
    color: white;
    text-decoration: none;
    font-weight: bold;   
    border-radius: 3px; 
}
.btn-danger:hover{
    background-color: #c0392b;
}
</style>

<?php include('partials/menu.php'); ?>

<div class="main">
    <div class="wrapper">
     <h1>Manage Food</h1>
     <br /><br />
           <!-- Button to Add Food -->
           <a href="<?php echo SITEURL; ?>admin/add-food.php" class="btn-primary">Add Food</a>
           <br /><br /><br />

           <?php
           if(isset($_SESSION['add']))
           {
               echo $_SESSION['add'];
               unset ($_SESSION['add']);
           }
           if(isset($_SESSION['delete'])) // delete session is created or not
           {
               echo $_SESSION['delete'];  //displaying if created
               unset ($_SESSION['delete']); 
           }
           if(isset($_SESSION['unauthorized'])) // delete session is created or not
           {
               echo $_SESSION['unauthorized'];  //displaying if created
               unset ($_SESSION['unauthorized']); 
           }
           if(isset($_SESSION['update'])) // delete session is created or not
           {
               echo $_SESSION['update'];  //displaying if created
               unset ($_SESSION['update']); 
           }
           ?>
           <table>
               <tr>
                   <td>ID</td>
                   <td>Title</td>
                   <td>Price</td>
                   <td>Image</td>
                   <td>Featured</td>
                   <td>Active</td>
                   <td>Actions</td>
                </tr>
             
                <?php
                 //Create q sql query to get all food
                 $sql = "SELECT * FROM table_food";
                 //execute it
                 $res=mysqli_query($conn, $sql);
                 //count rows to check whether we have food or not
                 $count=mysqli_num_rows($res);

                 $sn=1;
                 if($count>0)
                 {
                     //get the food from db and display it
                     while($row=mysqli_fetch_assoc($res)) 
                     {
                         $id=$row['id'];
                         $title=$row['title'];
                         $price=$row['price'];
                         $image_name=$row['image_name'];
                         $featured=$row['featured'];
                         $active=$row['active'];
                         ?>

                <tr>
                   <td><?php echo $sn++ ?></td>
                   <td><?php echo $title; ?></td>
                   <td><?php echo $price; ?></td>
                   <td><?php 
                     if($image_name=="")
                     {
                         echo "<div class='error'>Image not added!</div>";
                     }
                     else
                     {
                         ?>
                         <img src="<?php echo SITEURL; ?>images/food/<?php echo $image_name; ?>" width="200px" height="200px">
                         <?php
                     }

                      ?></td>
                   <td><?php echo $featured; ?></td>
                   <td><?php echo $active; ?></td>

                   <td>
                       <a href="<?php echo SITEURL; ?>admin/update-food.php?id=<?php echo $id; ?>" class="btn-secondary">Update Food</a>
                       <a href="<?php echo SITEURL; ?>admin/delete-food.php?id=<?php echo $id; ?>" class="btn-danger">Delete Food</a>
                   </td>
                </tr>
                <?php
                     }
                 }
                 else
                 {
                     echo "<tr> <td colspan='6' class='error'>Food Not Added Yet</td><tr>";
                 }
                ?>
            <table>     
    </div>
</div>
<br><br>
<?php include('partials/footer.php'); ?>