<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #D6EEEE;
}
.btn-primary{
    background-color: #16a085;
    padding: 1%;
    color: white;
    text-decoration: none;
    font-weight: bold;
    border-radius: 2px;
}
.btn-primary:hover{
    background-color: #27ae60;
}
.btn-secondary{
    background-color: black;
    padding: 1%;
    color: white;
    text-decoration: none;
    font-weight: bold;
    border-radius: 4px;    
}
.btn-secondary:hover{
    background-color: #c0392b;
}
.btn-danger{
    background-color: #8e44ad;
    padding: 1%;
    color: white;
    text-decoration: none;
    font-weight: bold;  
    border-radius: 4px;    
  
}
.btn-danger:hover{
    background-color: #c0392b;
}

 </style>

<?php include('partials/menu.php'); ?>

         <!-- main content section starts -->
         <div class="main">
         <div class="wrapper">
             <h1>Manage Admin</h1>
             <br />

             <?php 
              if(isset($_SESSION['add'])) {
                  echo $_SESSION['add'];
                  unset($_SESSION['add']);
              }

              if(isset($_SESSION['delete'])) {
                  echo $_SESSION['delete'];
                  unset($_SESSION['delete']);
              }

              if(isset($_SESSION['update'])) {
                echo $_SESSION['update'];
                unset($_SESSION['update']);
            }
            ?>
            <br><br><br>

             <!-- Button to Add Admin -->
             <a href="add-admin.php" class="btn-primary"> Add Admin </a>
             <br /><br /><br />

             <table>
                 <tr>
                     <th>ID</th>
                     <th>Full Name</th>
                     <th>User Name</th>
                     <th>Actions</th>
                </tr>

                <?php 
                   $sql = "SELECT * FROM table_admin";
                   $res = mysqli_query($conn, $sql);
                   if($res==TRUE)
                   {
                       //counting the number of rows in database
                       $count = mysqli_num_rows($res); //get all rows in db
                       $sn=1;

                       if($count>0)
                       {
                           while($rows=mysqli_fetch_assoc($res))
                       {
                           $id=$rows['id'];
                           $full_name=$rows['full_name'];
                           $username=$rows['username'];
                          ?> 
                        
                <tr>
                       <td><?php echo $sn++;  ?></td>
                       <td><?php echo $full_name; ?></td>
                       <td><?php echo $username  ?></td>
                    <td>
                       <a href="<?php echo SITEURL; ?>admin/update-admin.php?id=<?php echo $id; ?>" class="btn-secondary"> Update Admin</a>
                       <a href="<?php echo SITEURL; ?>admin/delete-admin.php?id=<?php echo $id; ?>" class="btn-danger"> Delete Admin</a>
                     </td>
                </tr>
                <?php
                       }
                    }
                    else{

                       }
                    }
                ?>
             </table>


            </div>
        </div>
        <!-- main content section ends -->

<?php include('partials/footer.php'); ?>