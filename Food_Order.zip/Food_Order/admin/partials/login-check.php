<?php
   //Authorization
   //Check whether the user is logged in or out
   if(!isset($_SESSION['user'])) { // if user session is not set
    // user if not logged in
    // then redirect to login page with a message
    $_SESSION['no-login-message'] = "<div class='error'> Please login to acess Admin Panel</div>";
    header('location:'.SITEURL.'admin/login/php');
   }
 ?>
