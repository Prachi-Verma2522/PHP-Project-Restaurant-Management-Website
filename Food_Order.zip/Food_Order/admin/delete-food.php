<?php
       include('../config/constants.php');
 if(isset($_GET['id']))
 {         
      //Get the id and 
    $id = $_GET['id'];
    //delete it from db
    $sql = "DELETE FROM table_food WHERE id=$id";
    //execute query
    $res = mysqli_query($conn, $sql);
    //checking whether the query is executed or not and set msg according to that
    if($res==true) 
    {
        // Food deleted
        $_SESSION['delete'] = "<div class='success'>Food Deleted Successfully</div>";
        header('location:'.SITEURL.'admin/manage-food.php');
    }
    else
    {
        //Failed to delete the food
        $_SESSION['delete'] = "<div class='error'>Failed to Delete the Food</div>";
        header('location:'.SITEURL.'admin/manage-food.php');
    }
}
 else
 {
     //redirect
    $_SESSION['unauthorized'] = "<div class='error'>Unauthorized Access</div>";
    header('location:'.SITEURL.'admin/manage-food.php');
 }
?>