<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #D6EEEE;
}
.btn-secondary{
    background-color: black;
    padding: 1%;
    color: white;
    text-decoration: none;
    font-weight: bold;    
}
.btn-secondary:hover{
    background-color: #c0392b;
}
</style>

<?php include('partials/menu.php'); ?>
<div class="main">
    <div class="wrapper">
        <h1>Add Category</h1>
        <br><br>

        <?php
        if(isset($_SESSION['add'])) 
        {
            echo $_SESSION['add'];
            unset($_SESSION['add']);
        }
        if(isset($_SESSION['upload']))
        {
            echo $_SESSION['upload'];
            unset($_SESSION['upload']);
        }
        ?>

        <br><br>

        <!-- Adding category -->
        <form action=""  method="POST" enctype="multipart/form-data">
        <table class="tbl-30">
                <tr>
                    <td>Title: </td>
                    <td><input type="text" name="title" placeholder="Category Title"></td>
                </tr>
                <tr>
                   <td>Choose Image: </td>
                   <td><input type="file" name="image"></td>
                </tr>
                <tr>
                    <td>Featured: </td>
                    <td>
                        <input type="radio" name="featured" value="Yes"> Yes
                        <input type="radio" name="featured" value="No"> No
                    </td>
                </tr>
                <tr>
                    <td>Active: </td>
                    <td>
                        <input type="radio" name="active" value="Yes">Yes
                        <input type="radio" name="featured" value="No">No
                    </td>
                </tr>
                <tr>
                    <td colspan="2"> <input type="submit" name="submit" value="Add Category" class="btn-secondary"></td>
                </tr>
            </table>
        </form>

        <?php 
        //Check whether the submit button is clicked or not
        if(isset($_POST['submit']))
        {
            //1.Get value from the category form
            $title = $_POST['title'];
            // For radio type input we need to check whether button is clicked or not
            if(isset($_POST['featured']))
            {
                // Get value from the form
                $featured = $_POST['featured'];
            }
            else
            {
                //Setting the default value
                $featured = "No";
            }
            if(isset($_POST['active']))
            {
                $active = $_POST['active'];
            }
            else
            {
                $active = "No";
            }

            // Image is selected or not and set the value for image name accordingly
            //print_r($_FILES["image"]);
            //die();// break the code here


          if(isset($_FILES['image']['name'])) 
          {
              //upload image if name is present
              //to upload an image we need image name, source path and destination path
              $image_name = $_FILES['image']['name'];
              //upload image only if image is selected
              if($image_name !="")
              {
              // Auto rename the image name and getting extension
              $ext = end(explode('.', $image_name));
              //renaming
              $image_name = "Food_Category_".rand(000, 999).'.'.$ext;


              $source_path = $_FILES['image']['tmp_name'];
              $destination_path = "../images/category/".$image_name;
              // upload the image now
              $upload = move_uploaded_file($source_path, $destination_path);
              // check whether image is uploaded or not
              //in case it's not uploaded then stop the process
              if($upload==false) {
                  //set message
                  $_SESSION['upload'] = "<div class='error'> Failed to Upload the Image</div>";
                  header('location:'.SITEURL.'admin/add-category.php');
                  die();//stop
              }
          }
        }
          else
          {  //otherwise don't upload the image and set the value as blank
            $image_name="";

          }

            //2. Create sql query to insert category int db
            $sql = "INSERT INTO table_category SET
                title='$title',
                image_name='$image_name',
                featured='$featured',
                active='$active'
                ";
            //3. Execute the query and save in the db
            $res = mysqli_query($conn, $sql);
            //4. check whether the query and data added or not
            if($res==true)
            {
                //query executed and added category
                $_SESSION['add'] = "<div class='success'> Category Added Successfully</div>";
                //redirect
                header('location:'.SITEURL.'admin/manage-category.php');
            }
            else{
                //failed to excute
                $_SESSION['add'] = "<div class='error'>Failed to Add Category</div>";
                //redirect
                header('location:'.SITEURL.'admin/add-category.php');
            }
        }
        ?>
    </div>
</div>
<?php include('partials/footer.php'); ?>